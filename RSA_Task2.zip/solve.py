import base64
import json
import sys
import requests
from Crypto.Util.number import long_to_bytes

def json_to_cookie(j: str) -> str:
    """Encode json data in a cookie-friendly way using base64."""
    # The JSON data is a string -> encode it into bytes
    json_as_bytes = j.encode()
    # base64-encode the bytes
    base64_as_bytes = base64.b64encode(json_as_bytes, altchars=b'-_')
    # b64encode returns bytes again, but we need a string -> decode it
    base64_as_str = base64_as_bytes.decode()
    return base64_as_str

def main(base_url):
    # Get the RSA public key from the /pk/ endpoint
    pk_url = f"{base_url}/pk/"
    pk_response = requests.get(pk_url)
    pk = pk_response.json()
    n = int(pk['N'])
    e = int(pk['e'])

    # Define the message
    message = b'You got a 12 because you are an excellent student! :)'

    # Calculate the signature
    signature = pow(int.from_bytes(message, byteorder='big'), e, n)
    signature = long_to_bytes(signature).hex()

    # Create the cookie
    c = json_to_cookie(json.dumps({'msg': message.hex(), 'signature': signature}))

    # Send the request
    resp = requests.get(f'{base_url}/quote/', cookies={'grade': c})
    print(resp.text)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f'usage: {sys.argv[0]} <base url>', file=sys.stderr)
        exit(1)
    main(sys.argv[1])