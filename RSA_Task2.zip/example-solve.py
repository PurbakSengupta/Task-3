import base64
import json
import math
import secrets
import string
from urllib.parse import quote as url_quote
from flask import Flask, request, make_response, redirect, url_for
from secret_data import rsa_key
import requests

import requests
import json
import base64

base_url = "http://127.0.0.1:5000"
#base_url = "https://example-server.com"
# Replace with the actual endpoint and parameters

def json_to_cookie(j: str) -> str:
    """Encode JSON data to be cookie-friendly using base64."""
    json_as_bytes = j.encode()
    base64_as_bytes = base64.b64encode(json_as_bytes, altchars=b'-_')
    base64_as_str = base64_as_bytes.decode()
    return base64_as_str

def cookie_to_json(base64_as_str: str) -> str:
    """Decode JSON data stored in a cookie-friendly format using base64."""
    assert all(char in (string.ascii_letters + string.digits + '-_=') for char in base64_as_str), \
            f"Input '{base64_as_str}' is not valid base64"
    json_as_bytes = base64.b64decode(base64_as_str, altchars=b'-_')
    json_as_str = json_as_bytes.decode()
    return json_as_str

# Retrieve the public key details
public_key_url = base_url + '/pk/'
response = requests.get(public_key_url)
public_key = response.json()  
n = public_key['N']
e = public_key['e']

# Step 1: Select two distinct messages m1 and m2
m1 = "This is a confidential message.".encode()
m2 = "This is a public message.".encode()

# Step 2: Request the server to sign m1 and m2
response1 = requests.get(f'http://localhost:5000/sign/{m1.hex()}')
s1 = int(json.loads(response1.text)['signature'], 16)

response2 = requests.get(f'http://localhost:5000/sign/{m2.hex()}')
s2 = int(json.loads(response2.text)['signature'], 16)

# Step 3: Calculate the new signature s
s_new = (s1 * s2) % n

# Step 4: Pair the new message with the new signature
new_message = {"message": m2.hex(), "signature": hex(s_new)}

json_data = json.dumps(new_message)
cookie_data = json_to_cookie(json_data)

response = requests.get('http://localhost:5000/verify/', cookies={'message_signature': cookie_data})
print(response.text)
